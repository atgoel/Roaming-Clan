<?php 
echo 'Nothing to view here.';